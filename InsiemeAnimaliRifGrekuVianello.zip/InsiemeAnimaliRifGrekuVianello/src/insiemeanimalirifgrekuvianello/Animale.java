package insiemeanimalirifgrekuvianello;


import java.util.Objects;

public class Animale {
    private String nome;
    private Specie specie;        ;
    
    public Animale(String nome, Specie specie){
        this.nome = nome;
        this.specie = specie;
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Specie getSpecie() {
        return specie;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + Objects.hashCode(this.nome);
        hash = 31 * hash + Objects.hashCode(this.specie);
        return hash;
    }

    public void setSpecie(Specie specie) {
        this.specie = specie;
        
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animale other = (Animale) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.specie, other.specie)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Animale{" + "nome=" + nome + ", specie=" + specie + '}';
    }

}

