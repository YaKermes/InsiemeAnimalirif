/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insiemeanimalirifgrekuvianello;

import java.util.Objects;
import java.util.ArrayList;

public class InsiemeAnimali {

    private ArrayList<Animale> insieme;
    private String nome;

    public InsiemeAnimali(String nome) {
        this(new ArrayList<Animale>());
        insieme = new ArrayList<>();
        this.nome = nome;
    }
    
    public String getNome(){
        return nome;
    }

    public int getDimensione() {
        ArrayList<Animale> sk = new ArrayList<>();
        sk = getInsieme();
        return sk.size();
    }

    public ArrayList<Animale> getInsieme() {
        return insieme;
    }

    public InsiemeAnimali(ArrayList<Animale> insieme) {
        this.insieme = insieme;
    }

    public int getNumSpecie(InsiemeAnimali insieme, Specie Specie) {
        int numerospeci = 0;
        for (int i = 0; i < insieme.getDimensione(); i++) {

            if ((getInsieme().get(i)).getSpecie() == Specie) {
                numerospeci++;
            }

        }
        return numerospeci;
    }

    void add(Animale a) {
        if (!insieme.contains(a)) {
            insieme.add(a);
        }
    }

    @Override
    public String toString() {
        return "InsiemeAnimali{" + "insieme=" + insieme + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final InsiemeAnimali other = (InsiemeAnimali) obj;
        if (this.insieme.size() != other.insieme.size()) {
            return false;
        }

        for (int i = 0; i < this.insieme.size(); i++) {
            Animale a = this.insieme.get(i);
            if (!other.insieme.contains(a)) {
                return false;
            }
        }
        return true;
    }

    int quantiPerTipo(String tipo) {
        int tot = 0;
        for (Animale a : insieme) {
            if (a.getSpecie().equals(tipo)) {
                tot++;
            }
        }
        return tot;
    }

}
