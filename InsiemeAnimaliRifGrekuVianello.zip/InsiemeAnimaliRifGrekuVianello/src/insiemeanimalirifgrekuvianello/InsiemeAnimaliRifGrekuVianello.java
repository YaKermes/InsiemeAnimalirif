/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insiemeanimalirifgrekuvianello;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author NIKOLA.GREKU
 */
public class InsiemeAnimaliRifGrekuVianello {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Specie s1 = new Specie("rana", "gracida", 2);
        Specie s2 = new Specie("cervo", "bramisce", 15);
        Specie s3 = new Specie("cavallo", "nitrisce", 12);
        Specie s4 = new Specie("gatto", "miagola", 4);

        Animale a1 = new Animale("Kermit", s1);
        Animale a2 = new Animale("Bambi", s2);
        InsiemeAnimali ia1 = new InsiemeAnimali("ia1");
        ia1.add(a1);
        ia1.add(a2);

        Animale a3 = new Animale("Bucefalo", s3);
        Animale a4 = new Animale("Flip the Frog", s1);
        Animale a5 = new Animale("Silvestro", s4);
        InsiemeAnimali ia2 = new InsiemeAnimali("ia2");
        ia2.add(a1);
        ia2.add(a3);
        ia2.add(a4);
        ia2.add(a5);

        InsiemeAnimali ia3 = new InsiemeAnimali("ia3");
        ia3.add(a2);
        ia3.add(a1);

        InsiemeAnimali ia4 = new InsiemeAnimali("ia4");
        ia4.add(a2);
        ia4.add(a5);

        InsiemeAnimali ia5 = new InsiemeAnimali("ia5");
        ia5.add(a2);
        ia5.add(a5);
        ia5.add(a3);

        ArrayList<InsiemeAnimali> insiemitotali = new ArrayList<>();
        insiemitotali.add(ia1);
        insiemitotali.add(ia2);
        insiemitotali.add(ia3);
        insiemitotali.add(ia4);
        
 // stampare contenunto insiemi d'esempio
        
        System.out.println("Insieme ia1 contiene " +ia1);
        System.out.println("Insieme ia1 contiene " +ia2);
        System.out.println("Insieme ia1 contiene " +ia3);
        System.out.println("Insieme ia1 contiene " +ia4);
        System.out.println("Insieme ia1 contiene " +ia5);

 // dire se ia1 e ia3 sono uguali
        
        if (ia1.equals(ia3))
            System.out.println("gli insiemi ia1 e ia3 sono uguali");
        else
            System.out.println("gli insiemi ia1 e ia3 non sono uguali");
        
// dire se ia1 e ia2 sono uguali
        
        if (ia1.equals(ia2))
            System.out.println("gli insiemi ia1 e ia2 sono uguali");
        else
            System.out.println("gli insiemi ia1 e ia2 non sono uguali"); 
        
 // dire se ia3 e ia4 sono uguali
        
        if (ia3.equals(ia4))
            System.out.println("gli insiemi ia3 e ia4 sono uguali");
        else
            System.out.println("gli insiemi ia3 e ia4 non sono uguali");
        
//dire il numero di una specie in un insieme e verificare 2 speci rana in ia2

        int speciranaia4 = ia2.getNumSpecie(ia2, s1);

        System.out.println("Nell' Insieme ia2 ci sono " + speciranaia4 + " Speci rana");
        
//Ristampare ia3 dopo aver aggiunto di nuovo Animale a1
        
        ia3.add(a1);
        
         System.out.println("Insieme ia3 dopo ulteriore aggiunta di rana Kermit contiene " +ia3);

//dire quale è il più grande
       
        
        int numAnimaliMax;
        
          ArrayList<Integer> numeroAnimali = new ArrayList<Integer>();
          numeroAnimali.add(ia1.getDimensione());
          numeroAnimali.add(ia2.getDimensione());
          numeroAnimali.add(ia3.getDimensione());
          numeroAnimali.add(ia4.getDimensione());
          numeroAnimali.add(ia5.getDimensione());
          
         numAnimaliMax = Collections.max(numeroAnimali);


        System.out.println("L'insieme più grande è ia2 con animali " + numAnimaliMax);

 //dire la potenza sonora dell'Insieme più rumoroso
        ArrayList<Integer> potenze = new ArrayList<Integer>();

        int potenza1 = ia1.getInsieme().get(0).getSpecie().getPotenza()
                + ia1.getInsieme().get(1).getSpecie().getPotenza();

        potenze.add(potenza1);

        int potenza2 = ia2.getInsieme().get(0).getSpecie().getPotenza()
                + ia2.getInsieme().get(1).getSpecie().getPotenza()
                + ia2.getInsieme().get(2).getSpecie().getPotenza()
                + ia2.getInsieme().get(3).getSpecie().getPotenza();

        potenze.add(potenza2);

        int potenza3 = ia3.getInsieme().get(0).getSpecie().getPotenza()
                + ia3.getInsieme().get(1).getSpecie().getPotenza();

        potenze.add(potenza3);

        int potenza4 = ia4.getInsieme().get(0).getSpecie().getPotenza()
                + ia4.getInsieme().get(1).getSpecie().getPotenza();

        potenze.add(potenza4);

        int potenza5 = ia5.getInsieme().get(0).getSpecie().getPotenza()
                + ia5.getInsieme().get(1).getSpecie().getPotenza()
                + ia5.getInsieme().get(2).getSpecie().getPotenza();
        potenze.add(potenza5);
        
        int potenzaGrande = Collections.max(potenze);
        
  
            
        System.out.println("La potenza sonora più elevata (insieme ia5) è " +potenzaGrande);
    }
}
