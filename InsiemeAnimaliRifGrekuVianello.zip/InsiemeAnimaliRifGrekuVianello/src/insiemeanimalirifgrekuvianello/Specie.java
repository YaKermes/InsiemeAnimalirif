/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insiemeanimalirifgrekuvianello;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.Objects;

public class Specie {
        private String spec, verso;
        private int potenza;
    
    public Specie(String spec, String verso,int potenza){
        this.spec = spec;
        this.verso = verso;
        this.potenza = potenza;
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }

    public String getVerso() {
        return verso;
    }

    public void setVerso(String verso) {
        this.verso = verso;
    }

    public int getPotenza() {
        return potenza;
    }

    public void setPotenza(int potenza) {
        this.potenza = potenza;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Specie other = (Specie) obj;
        if (!Objects.equals(this.spec, other.spec)) {
            return false;
        }
        if (!Objects.equals(this.verso, other.verso)) {
            return false;
        }
        if (!Objects.equals(this.potenza, other.potenza)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Specie{" + "spec=" + spec + ", verso=" + verso + ", potenza=" + potenza + '}';
    }
    
}
